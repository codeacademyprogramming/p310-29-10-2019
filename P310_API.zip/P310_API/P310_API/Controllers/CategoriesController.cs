﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.TagHelpers;
using Microsoft.EntityFrameworkCore;
using P310_API.DAL;
using P310_API.Model;

namespace P310_API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CategoriesController : Controller
    {
        private readonly P310_API.DAL.AppContext _context;

        public CategoriesController(P310_API.DAL.AppContext context)
        {
            _context = context;
        }

        public IActionResult Get()
        {
            return Ok(_context.Categories.Include(c => c.Products));
        }

        [HttpGet("{id}/{take}")]
        public async Task<IActionResult> Get(int id, int take)
        {
            var category = 
                await _context.Categories.Include(c => c.Products).FirstOrDefaultAsync(c => c.Id == id);

            if(category == null)
            {
                return NotFound("Specified id not found");
            }

            return Ok(category.Products.Take(take));
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromQuery]Category category)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest("Category is not valid");
            }

            if(_context.Categories.Any(c => c.Name == category.Name))
            {
                return BadRequest("Category name is duplicate");
            }

            await _context.Categories.AddAsync(category);
            await _context.SaveChangesAsync();

            return Created($"/api/categories/{category.Id}", category);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var category =
                await _context.Categories.Include(c => c.Products).FirstOrDefaultAsync(c => c.Id == id);

            if (category == null)
            {
                return NotFound("Specified id not found");
            }

            _context.Categories.Remove(category);
            await _context.SaveChangesAsync();

            return Ok("Category succeffully deleted");
        }
    }
}